esp32.ino adalah file Arduino Ide yang saya buat menggunkan wokwi 
splashScreen.apk adalah aolikasi yang sudah saya build 
SplasScreen(1).aia adalah aplikasi yang sudah saya ekport dan teman teman bisa mengimport nya dalam website kodular